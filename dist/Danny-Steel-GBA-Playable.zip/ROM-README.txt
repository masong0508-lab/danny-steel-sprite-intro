THE LAST DAYS OF DANNY STEEL - Game Boy Advance
Includes the current playable Old Quarter chapter, not the unfinished full campaign.
ROM: danny_steel_title.gba
Run in mGBA or Pizza Boy GBA, with SRAM saves enabled (32 KB/Auto).
Title: START. Menu: D-pad (both axes), A or START select, B back.
Save erase requires a deliberate uninterrupted 40-frame A hold.
Exploration: D-pad move, A interact, L/SELECT view, R notes, START pause.
Source commit: a9843a53a0acb882b6cbb6f2173c5eb06b2703aa
